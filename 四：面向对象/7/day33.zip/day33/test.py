#
#
# x=3
#
#
#
#
# for i in range(10):  # for循环不能开辟作用域
#     x=55
#
# def f():
#     x=5
#     y=4
#
#     print(x)
#
#
# class A():
#     c=3
#
#
# print(c)
#


def add(x,y):

    return x+y


import re