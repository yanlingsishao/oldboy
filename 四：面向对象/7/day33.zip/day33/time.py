import hashlib

print(time.time())