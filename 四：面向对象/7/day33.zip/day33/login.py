

import sys

# print(sys.argv)
#
# # username=sys.argv[1]
# # password=sys.argv[2]

print(sys.path)



