|--Readme.txt							#配置信息
|--practice1.py							#练习题
|--simulator_landing.py					#模拟登录
|--user_lock                            #锁定用户信息
|--three_lv.py                          #三级目录
|--省市.json                             #省市json文件