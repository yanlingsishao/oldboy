#!/usr/bin/env python
# -*- coding:utf-8 -*- 
'''
Created on 2017年5月9日
@author: WangQiyuan

'''
# 1、使用while循环输入 1 2 3 ... 8 9 10
# i = 1
# while i <= 10:
#     print(i)
#     i += 1

# 2、求1 - 100的所有数的和
#(1)
# n = 0
#
# for i in range(1,101):
#         n += i
# print(n)
#2)
# n = 1
# sum = 0
# while n <= 100:
#     sum += n
#     n += 1
# print(sum)

# 3、输出 1-100 内的所有奇数
#(1)
# for i in range(1,100):
#     if i%2 == 1:
#         print (i)

#(2)
# n = 0
# while n<100:
#     if n % 2 == 1:
#         print(n)
#     n += 1

# 4、输出1 - 100内的所有偶数
#(1)
# for i in range(1,101):
#     if i%2 == 0:
#         print (i)
#(2)
# n = 1
# while n<101:
#     if n % 2 == 0:
#         print(n)
#     n += 1

# 5、求1-2+3-4 ... 99的值

# n = 1
# s = 0
# while n < 100:
#     if n % 2 == 0:
#         s -= n
#     else:
#         s += n
#     n += 1
# print(s)


